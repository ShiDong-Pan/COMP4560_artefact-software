- Core graph embeddings models and relative experiments are in folder GraphEmbeddings_Implementation.

Preparation:
python setup.py install
cd examples

For deepwalk experiments:
python deepwalk_cora.py


For LINEexperiments:
python LINE_cora.py


For deepwalk experiments:
python ndoe2vec_cora.py


- The CORA dataset is in the data folder. 
- The parameters can be changed in those .py files. 