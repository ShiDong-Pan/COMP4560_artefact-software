
import numpy as np

from ge.classify import read_node_label, Classifier
from sklearn.linear_model import LogisticRegression
from ge import Node2Vec
import matplotlib.pyplot as plt
import networkx as nx
from sklearn.manifold import TSNE


def evaluate_embeddings(embeddings):
    X, Y = read_node_label('../data/cora/cora_label.txt')
    tr_frac = 0.85
    print("Training classifier using {:.2f}% nodes...".format(
        tr_frac * 100))
    clf = Classifier(embeddings=embeddings, clf=LogisticRegression())
    clf.split_train_evaluate(X, Y, tr_frac)


def plot_embeddings(embeddings,):
    X, Y = read_node_label('../data/cora/cora_label.txt')

    emb_list = []
    for k in X:
        emb_list.append(embeddings[k])
    emb_list = np.array(emb_list)

    model = TSNE(n_components=2)
    node_pos = model.fit_transform(emb_list)

    color_idx = {}
    for i in range(len(X)):
        color_idx.setdefault(Y[i][0], [])
        color_idx[Y[i][0]].append(i)

    for c, idx in color_idx.items():
        plt.scatter(node_pos[idx, 0], node_pos[idx, 1], label=c)
    plt.legend()
    plt.show()


if __name__ == "__main__":
    G = nx.read_edgelist('../data/cora/new_cora_edgelist.txt',
                         create_using=nx.DiGraph(), nodetype=None)

    model = Node2Vec(G, walk_length=4, num_walks=256,p=1,q=4, workers=1)
    model.train(window_size=4, iter=15)
    embeddings = model.get_embeddings()
    # heter: 'micro': 0.7269372693726938, 'macro': 0.6884292048031021,
    
    #keys = embeddings.keys()
    #print(sorted(keys))
    #nx.draw(G, pos=nx.spring_layout(G), with_labels=False)
    #plt.show()
    for k,v in list(embeddings.items()):
        if int(k) > 2708:
            del embeddings[k]
    
    evaluate_embeddings(embeddings)
    #plot_embeddings(embeddings)
